function driver() {
    document.getElementById("form1").style.left="0px";
    document.getElementById("form2").style.left="-500px";
    document.getElementById("btn_top").style.left="150px";
}

function passenger() {
    document.getElementById("form1").style.left="400px";
    document.getElementById("form2").style.left="000px";
    document.getElementById("btn_top").style.left="0px";
}