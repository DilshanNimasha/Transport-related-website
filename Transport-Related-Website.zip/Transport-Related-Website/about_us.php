<!DOCTYPE html>
<html>
<head>
	<title>About us</title>
	<link rel="stylesheet" type="text/css" href="css/transporty.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	

</head>
<body>

<?php include'header.php'?>
<br>
<br>
<div class="about_us_body"><!--about_us_body-->

<div class="topic"><!--topic-->
			
    <div class="image6"><!--image6-->
        	
        	<img src="img/text-box.png">
        
     </div><!--image6-->

	 <div class="heading"><!--heading-->
			
			<h2><b>WHO<br>WE ARE</b></h2>  
		
	 </div><!--heading-->
        
</div><!--topic-->
		<br>
		<br>
        <div class="welcome"><!--welcome-->

			<div class="banner"><!--banner-->
				
				<img src="img/bus.jpg">
			
			</div><!--banner-->
			

			<div class="center"><!--center-->
		

			<p><b>Welcome To Transporty.lk</b></p>
		


		   </div><!--center-->

		   </div><!--welcome-->

		   <div class="text"><!--text-->
		   	<p> We have been a pioneer in booking online bus ticket in Sri Lanka since 2021.Through this service,long distance travelers can book bus seats anywhere in Sri Lanka.Our service open to you 24 hours a day.<br><br> The version of online booking services is to provide an easy and convenient way to book their ticketsthrough our system and you can get Visa,MasterCard(Credit/Debit),Easy Cash and bank de.posite bus details here.<br><br>Stay tuned with us to get the most efficient service for you.</p>

		   	
     	  </div><!--text-->
     	  <div  class="team"><!--team-->
		   		
              
		   		<h3>Our Team</h3>

		   	  

		  </div><!--team-->

		 <div class="member1"><!--member1-->

               <h4>Nilupul<br>Madawa</h4>
         <div class="image1"><!--image1-->
			<img src="img/nilupul.jpg">


		</div><!--image1-->

		</div><!--member1-->

		<div class="member2"><!--member2-->
        	<h4><b>Iresha<br>Prabodhani</b></h4>

        <div class="image2"><!--image2-->
        	<img src="img/me.jpg">

        </div><!--image2-->
        	
        </div><!--member2-->
        <div class="member3"><!--member3-->
        	<h4><b>Dilshan<br>Nimasha</b></h4>
        <div class="image3"><!--image3-->
        	<img src="img/nimasha.jpg">

        </div><!--image3-->


        </div><!--member3-->


        <div class="member4"><!--memeber4-->
        	<h4><b>Ishani<br>Udeshika</b></h4>
        <div class="image4"><!--image4-->
        	<img src="img/isha.jpg">

        </div><!--image4-->
        	
        </div><!--member4-->

        <div class="member5"><!--memeber5-->
        	<h4><b>Lasitha<br>Chathuminda</b></h4>
        <div class="image5"><!--image5-->
        	<img src="img/lasitha.jpg">

        </div><!--image5-->
        	
        </div><!--member5-->
         
  </div><!--about_us_body-->

  <?php include'footer.php'?>



<script type="text/javascript" src="js/transporty.js"></script>

</body>
</html>