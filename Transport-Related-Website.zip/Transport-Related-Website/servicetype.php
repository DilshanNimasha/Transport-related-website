<html>
<head>
<title>Transporty</title>
<link rel="stylesheet" href="css/servicetype.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include_once 'header.php';?>
<div class="boarder">
<div class="center" align="center">
<h1>Service Type</h1>
<hr>
<img src="img/normal.jpg" alt="bustype" width="900" height="300">
 <div class="al-box" align="center">
<div class="box">
<h2>Normal</h2>
<ul type="circle">
  <li>Not air-condition</li>
  <li>Seats are basic with very small legro</li>
  <li>Stops at almost all the bus stops</li>
  <li>Slower than semiluxuty</li>
  </ul>
  </div>
 
<div class="box"> 
<h2>Semi Luxury</h2>
<ul type="circle">
  <li>Not air-condition</li>
  <li>Seats are better than in normal</li>
  <li>There are curtains</li>
  <li>Back door is closed</li>
  <li>Only stops at major bus stops</li>
  </ul> </div>
 <div class="box">
<h2>Luxury</h2>
<ul type="circle">
  <li>Air-condition</li>
  <li>Faster</li>
  <li>Only stops in major cities </li>
  <li>Wifi Available</li>
  </ul></div>
</div>
 </div>
 </div>
 <?php include_once'footer.php';?>
</body>
</html>
